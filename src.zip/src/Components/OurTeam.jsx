import React from "react";
import images from "../pictures/group.jpg";

export const OurTeam = () => {
  return (
    <>
      <h1 className="text-center text-3xl  bg-white text-black">
        Core Features{" "}
      </h1>
      <div className="flex flex-row gap-10 bg-white pt-10 pb-10">
        <div className="card w-72  ml-10 shadow-xl">
          <figure>
            <img src={images} alt="Shoes" />
          </figure>
          <div className="card-body">
            <h2 className="card-title text-black">Creating Community</h2>
            <p className="text-base-300">
              We have created a platfrom where users can engage witheach by
              posting the places they have visited and their experience there
            </p>
            <div className="card-actions justify-end"></div>
          </div>
        </div>

        <div className="card w-72  ml-20 shadow-xl">
          <figure>
            <img src={images} alt="Shoes" />
          </figure>
          <div className="card-body">
            <h2 className="card-title text-black">AI Recommendation</h2>
            <p className="text-base-300">
              Harnessing the power of AI, it analyzes your preferences, and
              travel history to provide tailored recommendations.
            </p>
            <div className="card-actions justify-end"></div>
          </div>
        </div>

        <div className="card w-72  ml-20 shadow-xl">
          <figure>
            <img src={images} alt="Shoes" />
          </figure>
          <div className="card-body">
            <h2 className="card-title text-black">Bookings</h2>
            <p className="text-base-300">
              You get all the latest information about places you can visit and
              also book hotels rastaurants and park tickets to go there all in
              one platfrom.
            </p>
            <div className="card-actions justify-end"></div>
          </div>
        </div>
      </div>
    </>
  );
};
