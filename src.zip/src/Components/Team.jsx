import React from "react";
import image1 from "../pictures/dev-2.jpg";
import image2 from "../pictures/dev-2.jpg";
import image3 from "../pictures/dev-2.jpg";

function Team() {
  return (
    <div>
      <div className="bg-white py-24 sm:py-32">
        <div className="flex flex-col max-w-7xl gap-x-8 gap-y-20 px-6 lg:px-8 xl:grid-cols-3">
          <div className="flex flex-col justify-center">
            <h2 className="text-3xl font-bold tracking-tight text-center  text-gray-900 sm:text-4xl">
              Meet our Team
            </h2>
            <p className="mt-6 text-lg leading-8 text-center text-gray-600">
              We are
            </p>
          </div>
          <div className="flex flex-row">
            <ul role="list" className="flex flex-row ml-40 text-center gap-40">
              <li>
                <div className="flex flex-col items-center gap-x-6">
                  <img className="h-40 w-40 rounded-full" src={image1} alt="" />
                  <div>
                    <h3 className="text-base font-semibold leading-7 tracking-tight text-gray-900">
                      NAme3
                    </h3>
                    <p className="text-sm font-semibold leading-6 text-indigo-600">
                      sajakjsajshaj jkajskaj
                    </p>
                  </div>
                </div>
              </li>

              <li>
                <div className="flex flex-col items-center gap-x-6">
                  <img className="h-40 w-40 rounded-full" src={image2} alt="" />
                  <div>
                    <h3 className="text-base font-semibold leading-7 tracking-tight text-gray-900">
                      Name1
                    </h3>
                    <p className="text-sm font-semibold leading-6 text-indigo-600">
                      saja
                    </p>
                  </div>
                </div>
              </li>

              <li>
                <div className="flex flex-col items-center gap-x-6">
                  <img className="h-40 w-40 rounded-full" src={image3} alt="" />
                  <div>
                    <h3 className="text-base font-semibold leading-7 tracking-tight text-gray-900">
                      Name2
                    </h3>
                    <p className="text-sm font-semibold leading-6 text-indigo-600">
                      daa
                    </p>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Team;
